﻿using System;

namespace Assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            string angryProfessor(int k, vector<int>a)
            {
                int count = 0;
                for (int i = 0; i < a.size(); i++)
                {
                    if (a[i] <= 0)
                        count++;
                }
                string result;
                if (count < k)
                    result = "YES";
                else
                    result = "NO";
                return result;
            }
            
        }
    }
}
