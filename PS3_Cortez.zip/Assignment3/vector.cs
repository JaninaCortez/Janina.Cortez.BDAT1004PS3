﻿using System;

namespace Assignment3
{
    internal class vector<T>
    {
        internal int size()
        {
            throw new NotImplementedException();
        }
    }
}